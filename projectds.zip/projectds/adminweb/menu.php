<!-- <li class="">
	<a href="index.php?mod=barang"><i class="fas fa-money-bill-alt"></i> Barang</a>
</li>
<li class="">
	<a href="index.php?mod=kategori"><i class="fas fa-money-bill-alt"></i> Kategori</a>
</li>
<li class="">
	<a href="index.php?mod=level"><i class="fas fa-money-bill-alt"></i> Level</a>
</li> -->
<li class=""> 
	<a href="index.php?mod=obat"><i class="fas 	fa fa-medkit"></i> Obat</a>
</li>
<li class="">
	<a href="index.php?mod=pembelian"><i class="fas 	fa fa-medkit"></i> Jumlah Pembelian Obat</a>
</li>
<li class=""> 
	<a href="index.php?mod=pemesanan"><i class="fas 	fa fa-medkit"></i> Jumlah Pemesanan Obat</a>
</li>
<li class=""> 
	<a href="index.php?mod=prediksi"><i class="fas 	fa fa-medkit"></i> Prediksi Obat Jumlah Pembelian</a>
</li>
<li class=""> 
	<a href="index.php?mod=prediksi2"><i class="fas 	fa fa-medkit"></i> Prediksi Obat Jumlah Pemesanan</a>
</li>
<li>
    <a href="logout.php">Log Out</a>
</li>