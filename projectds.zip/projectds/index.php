<?php
	header("location:./adminweb/index_login.php");
?>
